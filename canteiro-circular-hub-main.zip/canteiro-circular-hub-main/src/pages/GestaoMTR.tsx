import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  ArrowLeft, 
  Search, 
  Filter, 
  Download, 
  Edit,
  Plus,
  FileText,
  Calendar,
  MapPin
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { NewMTRDialog } from "@/components/dialogs/NewMTRDialog";
import { exportMTRData } from "@/utils/exportUtils";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function GestaoMTR() {
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [showNewMTRDialog, setShowNewMTRDialog] = useState(false);
  const [mtrData, setMtrData] = useState<any[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    loadMTRData();
  }, [user]);

  const loadMTRData = () => {
    if (!user) return;
    
    const storedMTRs = JSON.parse(localStorage.getItem('mtrs') || '[]');
    const userMTRs = storedMTRs.filter((mtr: any) => mtr.user_id === user.id);
    setMtrData(userMTRs);
  };

  const filteredData = mtrData.filter(mtr => {
    const matchesSearch = mtr.mtr_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         mtr.project_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || mtr.status.toLowerCase() === statusFilter;
    const matchesType = typeFilter === "all" || mtr.waste_type.toLowerCase().includes(typeFilter);
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const handleExport = () => {
    exportMTRData(filteredData);
    toast.success('Dados exportados com sucesso!');
  };

  const stats = [
    { label: "Total de MTRs", value: mtrData.length.toString(), color: "text-blue-600" },
    { label: "Ativos", value: mtrData.filter(m => m.status === 'ativo').length.toString(), color: "text-green-600" },
    { label: "Vencidos", value: mtrData.filter(m => new Date(m.due_date) < new Date()).length.toString(), color: "text-red-600" },
    { label: "Toneladas Total", value: mtrData.reduce((sum, m) => sum + (m.quantity || 0), 0).toFixed(1), color: "text-purple-600" }
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <Button variant="outline" onClick={() => window.history.back()} className="mb-4 md:mb-0">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Gestão de MTR</h1>
          <p className="text-gray-600 mt-1">Manifesto de Transporte de Resíduos</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Exportar Todos
          </Button>
          <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => setShowNewMTRDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Novo MTR
          </Button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-4 text-center">
              <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
              <div className="text-sm text-gray-600 mt-1">{stat.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Search className="h-5 w-5 mr-2" />
            Filtros de Busca
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <Input
                placeholder="Buscar por número MTR ou projeto..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Todos Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Status</SelectItem>
                <SelectItem value="ativo">Ativo</SelectItem>
                <SelectItem value="vencido">Vencido</SelectItem>
              </SelectContent>
            </Select>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Todos Tipos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Tipos</SelectItem>
                <SelectItem value="concreto">Concreto</SelectItem>
                <SelectItem value="aço">Aço</SelectItem>
                <SelectItem value="madeira">Madeira</SelectItem>
              </SelectContent>
            </Select>
            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Filtros Avançados
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* MTR List */}
      <div className="space-y-4">
        {filteredData.map((mtr) => (
          <Card key={mtr.id} className="hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                <div className="flex-1 space-y-2">
                  <div className="flex items-center space-x-3">
                    <h3 className="text-lg font-semibold text-gray-900">{mtr.mtr_number}</h3>
                    <Badge className={mtr.statusColor}>{mtr.status}</Badge>
                  </div>
                  <p className="text-gray-600">{mtr.project_name}</p>
                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <div className="flex items-center">
                      <FileText className="h-4 w-4 mr-1" />
                      {mtr.waste_type}: {mtr.quantity}
                    </div>
                    <div className="flex items-center">
                      <Calendar className="h-4 w-4 mr-1" />
                      Vence: {mtr.due_date}
                    </div>
                    <div className="flex items-center">
                      <MapPin className="h-4 w-4 mr-1" />
                      {mtr.location}
                    </div>
                  </div>
                </div>
                <div className="flex items-center space-x-2 mt-4 md:mt-0">
                  <Button variant="outline" size="sm">
                    <Edit className="h-4 w-4 mr-2" />
                    Editar
                  </Button>
                  <Button variant="outline" size="sm">
                    <Download className="h-4 w-4 mr-2" />
                    Download
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <NewMTRDialog
        isOpen={showNewMTRDialog}
        onClose={() => setShowNewMTRDialog(false)}
        onSuccess={loadMTRData}
      />
    </div>
  );
}
