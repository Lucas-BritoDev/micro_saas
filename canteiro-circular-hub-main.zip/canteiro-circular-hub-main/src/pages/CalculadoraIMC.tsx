import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { IMCQuestions } from '@/components/imc/IMCQuestions';
import { IMCResults } from '@/components/imc/IMCResults';
import { ArrowLeft, FileDown, Calendar, ChevronRight, ChevronLeft } from 'lucide-react';
import { exportIMCResults } from '@/utils/exportUtils';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface Question {
  id: string;
  category: string;
  question: string;
  options: { value: string; label: string; points: number }[];
}

interface AssessmentResult {
  score: number;
  category_scores: {
    environmental: number;
    social: number;
    governance: number;
  };
}

const questions = [
  {
    id: 'q1',
    category: 'Gestão de Materiais',
    question: 'Como sua empresa gerencia o inventário de materiais de construção?',
    options: [
      { value: 'manual', label: 'Controle manual/planilhas', points: 1 },
      { value: 'basico', label: 'Sistema básico de controle', points: 2 },
      { value: 'integrado', label: 'Sistema integrado com fornecedores', points: 3 },
      { value: 'automatizado', label: 'Sistema totalmente automatizado com IoT', points: 4 }
    ]
  },
  {
    id: 'q2',
    category: 'Sustentabilidade',
    question: 'Qual o percentual de materiais sustentáveis utilizados nos projetos?',
    options: [
      { value: '0-25', label: '0-25%', points: 1 },
      { value: '26-50', label: '26-50%', points: 2 },
      { value: '51-75', label: '51-75%', points: 3 },
      { value: '76-100', label: '76-100%', points: 4 }
    ]
  },
  {
    id: 'q3',
    category: 'Gestão de Resíduos',
    question: 'Como é feito o gerenciamento de resíduos da construção?',
    options: [
      { value: 'descarte-comum', label: 'Descarte comum', points: 1 },
      { value: 'separacao-basica', label: 'Separação básica', points: 2 },
      { value: 'reciclagem-parcial', label: 'Reciclagem parcial', points: 3 },
      { value: 'economia-circular', label: 'Economia circular completa', points: 4 }
    ]
  },
  {
    id: 'q4',
    category: 'Tecnologia',
    question: 'Que tecnologias são utilizadas para otimizar processos?',
    options: [
      { value: 'nenhuma', label: 'Nenhuma tecnologia específica', points: 1 },
      { value: 'software-basico', label: 'Software básico de gestão', points: 2 },
      { value: 'bim-parcial', label: 'BIM e ferramentas avançadas', points: 3 },
      { value: 'ia-iot', label: 'IA, IoT e automação total', points: 4 }
    ]
  },
  {
    id: 'q5',
    category: 'Fornecedores',
    question: 'Como é feita a seleção e gestão de fornecedores?',
    options: [
      { value: 'preco-apenas', label: 'Apenas critério de preço', points: 1 },
      { value: 'qualidade-preco', label: 'Preço e qualidade', points: 2 },
      { value: 'sustentabilidade-incluida', label: 'Inclui critérios de sustentabilidade', points: 3 },
      { value: 'parceria-estrategica', label: 'Parceria estratégica com foco ESG', points: 4 }
    ]
  },
  {
    id: 'q6',
    category: 'Monitoramento',
    question: 'Como é feito o monitoramento do desempenho ambiental?',
    options: [
      { value: 'nao-monitora', label: 'Não há monitoramento', points: 1 },
      { value: 'relatorios-manuais', label: 'Relatórios manuais esporádicos', points: 2 },
      { value: 'indicadores-regulares', label: 'Indicadores regulares', points: 3 },
      { value: 'dashboard-tempo-real', label: 'Dashboard em tempo real', points: 4 }
    ]
  },
  {
    id: 'q7',
    category: 'Certificações',
    question: 'Sua empresa possui certificações ambientais?',
    options: [
      { value: 'nenhuma', label: 'Nenhuma certificação', points: 1 },
      { value: 'em-processo', label: 'Em processo de certificação', points: 2 },
      { value: 'certificacoes-basicas', label: 'Certificações básicas (ISO 14001)', points: 3 },
      { value: 'multiplas-certificacoes', label: 'Múltiplas certificações avançadas', points: 4 }
    ]
  },
  {
    id: 'q8',
    category: 'Inovação',
    question: 'Qual o nível de inovação em processos sustentáveis?',
    options: [
      { value: 'tradicional', label: 'Processos tradicionais', points: 1 },
      { value: 'melhorias-pontuais', label: 'Melhorias pontuais', points: 2 },
      { value: 'inovacao-regular', label: 'Inovação regular', points: 3 },
      { value: 'lideranca-inovacao', label: 'Liderança em inovação', points: 4 }
    ]
  },
  {
    id: 'q9',
    category: 'Treinamento',
    question: 'Como é feito o treinamento da equipe em sustentabilidade?',
    options: [
      { value: 'nenhum', label: 'Nenhum treinamento', points: 1 },
      { value: 'ocasional', label: 'Treinamentos ocasionais', points: 2 },
      { value: 'programa-regular', label: 'Programa regular de treinamento', points: 3 },
      { value: 'educacao-continua', label: 'Educação continuada obrigatória', points: 4 }
    ]
  },
  {
    id: 'q10',
    category: 'Governança',
    question: 'Como a sustentabilidade está integrada na governança?',
    options: [
      { value: 'nao-integrada', label: 'Não está integrada', points: 1 },
      { value: 'iniciativas-isoladas', label: 'Iniciativas isoladas', points: 2 },
      { value: 'politica-formal', label: 'Política formal estabelecida', points: 3 },
      { value: 'estrategia-central', label: 'Estratégia central do negócio', points: 4 }
    ]
  }
];

export default function CalculadoraIMC() {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [assessment, setAssessment] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const { user } = useAuth();

  const handleAnswerChange = (questionId: string, value: string) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(prev => prev + 1);
    }
  };

  const handlePrevious = () => {
    if (currentQuestion > 0) {
      setCurrentQuestion(prev => prev - 1);
    }
  };

  const calculateScore = () => {
    let totalScore = 0;
    const categoryScores = {
      environmental: 0,
      social: 0,
      governance: 0
    };

    Object.entries(answers).forEach(([questionId, value]) => {
      const question = questions.find(q => q.id === questionId);
      const option = question?.options.find(o => o.value === value);
      
      if (option) {
        totalScore += option.points;
        
        // Categorize scores
        if (['q1', 'q2', 'q3', 'q6'].includes(questionId)) {
          categoryScores.environmental += option.points;
        } else if (['q5', 'q7', 'q9'].includes(questionId)) {
          categoryScores.social += option.points;
        } else {
          categoryScores.governance += option.points;
        }
      }
    });

    return {
      score: Math.round((totalScore / (questions.length * 4)) * 100),
      category_scores: {
        environmental: Math.round((categoryScores.environmental / 16) * 100),
        social: Math.round((categoryScores.social / 12) * 100),
        governance: Math.round((categoryScores.governance / 12) * 100)
      }
    };
  };

  const handleSubmit = async () => {
    if (Object.keys(answers).length !== questions.length) {
      toast.error('Por favor, responda todas as perguntas');
      return;
    }

    setLoading(true);
    try {
      const result = calculateScore();
      
      if (user) {
        // For now, we'll store in localStorage until database tables are updated
        const assessmentData = {
          id: Date.now().toString(),
          user_id: user.id,
          answers,
          score: result.score,
          category_scores: result.category_scores,
          created_at: new Date().toISOString()
        };
        
        const existingAssessments = JSON.parse(localStorage.getItem('imc_assessments') || '[]');
        existingAssessments.push(assessmentData);
        localStorage.setItem('imc_assessments', JSON.stringify(existingAssessments));
        
        setAssessment(assessmentData);
        toast.success('Avaliação IMC concluída com sucesso!');
      }
    } catch (error) {
      console.error('Error saving assessment:', error);
      toast.error('Erro ao salvar avaliação');
    } finally {
      setLoading(false);
    }
  };

  const handleExportReport = () => {
    if (assessment) {
      exportIMCResults(assessment);
      toast.success('Relatório exportado com sucesso!');
    }
  };

  const handleScheduleConsulting = () => {
    const subject = 'Solicitação de Consultoria IMC';
    const body = `Olá,

Gostaria de agendar uma consultoria para melhorar nosso Índice de Maturidade Circular.

Dados da avaliação:
- Score IMC: ${assessment?.score}/100
- Score Ambiental: ${assessment?.category_scores?.environmental}/100
- Score Social: ${assessment?.category_scores?.social}/100
- Score Governança: ${assessment?.category_scores?.governance}/100

Aguardo contato.

Atenciosamente,
${user?.email}`;
    
    window.location.href = `mailto:consultoria@canteirocircular.com?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  const handleRestart = () => {
    setCurrentQuestion(0);
    setAnswers({});
    setAssessment(null);
  };

  if (assessment) {
    return (
      <div className="p-6">
        <div className="max-w-4xl mx-auto">
          <Button variant="outline" onClick={() => window.history.back()} className="mb-6">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          
          <IMCResults 
            assessment={assessment}
            onExportReport={handleExportReport}
            onScheduleConsulting={handleScheduleConsulting}
            onRestart={handleRestart}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <div className="max-w-4xl mx-auto">
        <div className="flex items-center justify-between mb-6">
          <div>
            <Button variant="outline" onClick={() => window.history.back()} className="mb-4">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Voltar
            </Button>
            <h1 className="text-2xl font-bold text-gray-900">Calculadora IMC</h1>
            <p className="text-gray-600">Índice de Maturidade Circular</p>
          </div>
          <Badge variant="outline" className="text-lg px-4 py-2">
            {Object.keys(answers).length}/{questions.length} respondidas
          </Badge>
        </div>

        <div className="space-y-6">
          <IMCQuestions
            questions={questions}
            answers={answers}
            onAnswerChange={handleAnswerChange}
            currentQuestion={currentQuestion}
          />

          <div className="flex justify-between">
            <Button 
              variant="outline" 
              onClick={handlePrevious}
              disabled={currentQuestion === 0}
            >
              <ChevronLeft className="h-4 w-4 mr-2" />
              Anterior
            </Button>

            {currentQuestion === questions.length - 1 ? (
              <Button 
                onClick={handleSubmit}
                disabled={loading || Object.keys(answers).length !== questions.length}
                className="bg-green-600 hover:bg-green-700"
              >
                {loading ? 'Calculando...' : 'Finalizar Avaliação'}
              </Button>
            ) : (
              <Button 
                onClick={handleNext}
                disabled={!answers[questions[currentQuestion].id]}
              >
                Próxima
                <ChevronRight className="h-4 w-4 ml-2" />
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
