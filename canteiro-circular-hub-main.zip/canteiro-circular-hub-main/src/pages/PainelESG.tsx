
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, Calendar, Download, TrendingUp, Leaf, Users, Shield } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';

const evolutionData = [
  { month: 'Mês 1', Environmental: 78, Social: 72, Governance: 85 },
  { month: 'Mês 2', Environmental: 80, Social: 74, Governance: 87 },
  { month: 'Mês 3', Environmental: 82, Social: 76, Governance: 88 },
];

const wasteDistribution = [
  { name: 'Concreto', value: 45, color: '#10B981' },
  { name: 'Aço', value: 25, color: '#3B82F6' },
  { name: 'Madeira', value: 20, color: '#F59E0B' },
  { name: 'Outros', value: 10, color: '#8B5CF6' },
];

const goals2024 = [
  {
    title: "Reduzir emissões de CO₂ em 30%",
    progress: 78,
    status: "Em progresso",
    color: "bg-green-500"
  },
  {
    title: "Certificação ISO 14001",
    progress: 85,
    status: "Progresso",
    color: "bg-purple-500"
  },
  {
    title: "Treinar 100% dos funcionários",
    progress: 32,
    status: "Progresso",
    color: "bg-blue-500"
  },
  {
    title: "Aumentar materiais reciclados",
    progress: 45,
    status: "Progresso",
    color: "bg-orange-500"
  }
];

export default function PainelESG() {
  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <Button variant="outline" onClick={() => window.history.back()} className="mb-4 md:mb-0">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Painel ESG</h1>
          <p className="text-gray-600 mt-1">Environmental, Social & Governance</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <Button variant="outline" size="sm">
            <Calendar className="h-4 w-4 mr-2" />
            3 meses
          </Button>
          <Button variant="outline" size="sm" className="bg-green-600 hover:bg-green-700 text-white">
            <Download className="h-4 w-4 mr-2" />
            Exportar Relatório
          </Button>
        </div>
      </div>

      {/* Alert */}
      <Card className="bg-green-50 border-green-200">
        <CardContent className="p-4">
          <div className="flex items-center">
            <TrendingUp className="h-5 w-5 text-green-600 mr-2" />
            <span className="text-green-800 font-medium">
              Visualizando dados dos últimos 3 meses
            </span>
          </div>
        </CardContent>
      </Card>

      {/* ESG Scores */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-green-50 border-green-200">
          <CardHeader className="text-center">
            <Leaf className="h-8 w-8 mx-auto text-green-600 mb-2" />
            <CardTitle className="text-green-800">Ambiental (E)</CardTitle>
            <CardDescription>Environmental</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <div className="text-4xl font-bold text-green-600 mb-2">82/100</div>
            <div className="text-sm text-green-700">+3 pts</div>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="text-center">
            <Users className="h-8 w-8 mx-auto text-blue-600 mb-2" />
            <CardTitle className="text-blue-800">Social (S)</CardTitle>
            <CardDescription>Social</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <div className="text-4xl font-bold text-blue-600 mb-2">76/100</div>
            <div className="text-sm text-blue-700">+2 pts</div>
          </CardContent>
        </Card>

        <Card className="bg-purple-50 border-purple-200">
          <CardHeader className="text-center">
            <Shield className="h-8 w-8 mx-auto text-purple-600 mb-2" />
            <CardTitle className="text-purple-800">Governança (G)</CardTitle>
            <CardDescription>Governance</CardDescription>
          </CardHeader>
          <CardContent className="text-center">
            <div className="text-4xl font-bold text-purple-600 mb-2">88/100</div>
            <div className="text-sm text-purple-700">+4 pts</div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Evolução ESG</CardTitle>
            <CardDescription>Progresso dos indicadores ao longo do tempo</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={evolutionData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="month" />
                <YAxis domain={[60, 100]} />
                <Tooltip />
                <Line type="monotone" dataKey="Environmental" stroke="#10B981" strokeWidth={2} />
                <Line type="monotone" dataKey="Social" stroke="#3B82F6" strokeWidth={2} />
                <Line type="monotone" dataKey="Governance" stroke="#8B5CF6" strokeWidth={2} />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Distribuição de Resíduos</CardTitle>
            <CardDescription>Percentual por tipo de material</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={wasteDistribution}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                >
                  {wasteDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="grid grid-cols-2 gap-2 mt-4">
              {wasteDistribution.map((item, index) => (
                <div key={index} className="flex items-center text-sm">
                  <div 
                    className="w-3 h-3 rounded-full mr-2" 
                    style={{ backgroundColor: item.color }}
                  ></div>
                  <span>{item.name}: {item.value}%</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Goals 2024 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 mr-2 text-blue-600" />
            Metas ESG 2024
          </CardTitle>
          <CardDescription>Acompanhamento do progresso das metas estabelecidas</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {goals2024.map((goal, index) => (
              <div key={index} className="space-y-3">
                <div className="flex items-center justify-between">
                  <h4 className="font-medium text-gray-900">{goal.title}</h4>
                  <span className="text-sm font-medium text-gray-600">{goal.progress}%</span>
                </div>
                <Progress value={goal.progress} className="h-2" />
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-500">{goal.status}</span>
                  <div className={`w-2 h-2 rounded-full ${goal.color}`}></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
