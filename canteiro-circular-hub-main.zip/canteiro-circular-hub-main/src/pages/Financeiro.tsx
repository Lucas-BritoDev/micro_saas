import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Plus, TrendingUp, TrendingDown, DollarSign, Edit, Trash2 } from "lucide-react";
import { NewTransactionDialog } from "@/components/dialogs/NewTransactionDialog";
import { exportFinancialData } from "@/utils/exportUtils";
import { useAuth } from "@/contexts/AuthContext";
import { toast } from "sonner";

export default function Financeiro() {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [showNewTransactionDialog, setShowNewTransactionDialog] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState<any>(null);
  const { user } = useAuth();

  useEffect(() => {
    loadTransactions();
  }, [user]);

  const loadTransactions = () => {
    if (!user) return;
    
    const storedTransactions = JSON.parse(localStorage.getItem('financial_transactions') || '[]');
    const userTransactions = storedTransactions.filter((t: any) => t.user_id === user.id);
    setTransactions(userTransactions);
  };

  const handleEdit = (transaction: any) => {
    setEditingTransaction(transaction);
    setShowNewTransactionDialog(true);
  };

  const handleDelete = async (transactionId: string) => {
    if (!confirm('Tem certeza que deseja remover esta transação?')) return;
    
    try {
      const existingTransactions = JSON.parse(localStorage.getItem('financial_transactions') || '[]');
      const updatedTransactions = existingTransactions.filter((t: any) => t.id !== transactionId);
      localStorage.setItem('financial_transactions', JSON.stringify(updatedTransactions));
      
      loadTransactions();
      toast.success('Transação removida com sucesso!');
    } catch (error) {
      console.error('Error deleting transaction:', error);
      toast.error('Erro ao remover transação');
    }
  };

  const handleExport = () => {
    exportFinancialData(transactions);
    toast.success('Dados financeiros exportados com sucesso!');
  };

  const totalReceitas = transactions
    .filter(t => t.type === 'income')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const totalDespesas = transactions
    .filter(t => t.type === 'expense')
    .reduce((sum, t) => sum + t.amount, 0);
    
  const saldo = totalReceitas - totalDespesas;

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <Button variant="outline" onClick={() => window.history.back()} className="mb-4 md:mb-0">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Painel Financeiro</h1>
          <p className="text-gray-600 mt-1">Controle financeiro por projeto</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <Button variant="outline" size="sm" onClick={handleExport}>
            <DollarSign className="h-4 w-4 mr-2" />
            Exportar
          </Button>
          <Button size="sm" className="bg-green-600 hover:bg-green-700" onClick={() => setShowNewTransactionDialog(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Nova Transação
          </Button>
        </div>
      </div>

      {/* Financial Summary */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="bg-green-50 border-green-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-green-800">Total Receitas</CardTitle>
            <TrendingUp className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">
              R$ {totalReceitas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-red-50 border-red-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-red-800">Total Despesas</CardTitle>
            <TrendingDown className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">
              R$ {totalDespesas.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>

        <Card className="bg-blue-50 border-blue-200">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium text-blue-800">Saldo</CardTitle>
            <DollarSign className="h-4 w-4 text-blue-600" />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${saldo >= 0 ? 'text-blue-600' : 'text-red-600'}`}>
              R$ {saldo.toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Recent Transactions */}
      <Card>
        <CardHeader>
          <CardTitle>Transações</CardTitle>
          <CardDescription>Movimentações financeiras</CardDescription>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <DollarSign className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>Nenhuma transação encontrada</p>
              <p className="text-sm">Clique em "Nova Transação" para começar</p>
            </div>
          ) : (
            <div className="space-y-4">
              {transactions.map((transaction) => (
                <div 
                  key={transaction.id}
                  className="flex flex-col md:flex-row md:items-center md:justify-between p-4 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      <h4 className="font-medium text-gray-900">{transaction.description}</h4>
                      <Badge variant="secondary" className="text-xs">
                        {transaction.project}
                      </Badge>
                    </div>
                    <p className="text-sm text-gray-500">
                      {new Date(transaction.date).toLocaleDateString('pt-BR')}
                      {transaction.category && ` • ${transaction.category}`}
                    </p>
                  </div>
                  
                  <div className="flex items-center justify-between md:justify-end space-x-4 mt-3 md:mt-0">
                    <span className={`text-lg font-semibold ${transaction.type === 'income' ? 'text-green-600' : 'text-red-600'}`}>
                      {transaction.type === 'income' ? '+' : '-'}R$ {Math.abs(transaction.amount).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                    </span>
                    <div className="flex items-center space-x-2">
                      <Button variant="outline" size="sm" onClick={() => handleEdit(transaction)}>
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="outline" size="sm" onClick={() => handleDelete(transaction.id)}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <NewTransactionDialog
        isOpen={showNewTransactionDialog}
        onClose={() => {
          setShowNewTransactionDialog(false);
          setEditingTransaction(null);
        }}
        onSuccess={loadTransactions}
        editingTransaction={editingTransaction}
      />
    </div>
  );
}
