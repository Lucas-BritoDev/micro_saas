
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  ArrowLeft, 
  Search, 
  ChevronDown, 
  ChevronRight,
  MessageSquare,
  Phone,
  Mail,
  Calculator,
  FileText,
  Leaf,
  DollarSign,
  HelpCircle
} from "lucide-react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";

const faqData = [
  {
    category: "IMC",
    icon: Calculator,
    color: "bg-green-100 text-green-800",
    questions: [
      {
        question: "Como é calculado o Índice de Maturidade Circular?",
        answer: "O IMC é calculado através de uma avaliação abrangente que considera fatores ambientais, sociais e de governança, gerando uma pontuação de 0 a 100 pontos."
      }
    ]
  },
  {
    category: "MTR",
    icon: FileText,
    color: "bg-blue-100 text-blue-800",
    questions: [
      {
        question: "Qual a validade de um MTR?",
        answer: "O MTR possui validade conforme definido na legislação ambiental vigente, geralmente entre 30 a 90 dias dependendo do tipo de resíduo."
      },
      {
        question: "Como faço o download do MTR em PDF?",
        answer: "Acesse a seção Gestão MTR, localize o documento desejado e clique no botão 'Download' ao lado de cada MTR."
      }
    ]
  },
  {
    category: "ESG",
    icon: Leaf,
    color: "bg-purple-100 text-purple-800",
    questions: [
      {
        question: "O que são os indicadores ESG?",
        answer: "ESG significa Environmental, Social e Governance. São critérios que avaliam o desempenho sustentável de uma empresa nestas três dimensões."
      }
    ]
  },
  {
    category: "Financeiro",
    icon: DollarSign,
    color: "bg-orange-100 text-orange-800",
    questions: [
      {
        question: "Como categorizar despesas com sustentabilidade?",
        answer: "As despesas podem ser categorizadas por projeto, tipo de sustentabilidade (ambiental, social, governança) e centro de custo específico."
      }
    ]
  },
  {
    category: "Geral",
    icon: HelpCircle,
    color: "bg-gray-100 text-gray-800",
    questions: [
      {
        question: "Como exportar relatórios da plataforma?",
        answer: "Cada seção possui um botão 'Exportar' que permite baixar relatórios em PDF ou Excel com os dados filtrados."
      }
    ]
  }
];

export default function Suporte() {
  const [searchTerm, setSearchTerm] = useState("");
  const [openItems, setOpenItems] = useState<string[]>([]);

  const toggleItem = (id: string) => {
    setOpenItems(prev => 
      prev.includes(id) 
        ? prev.filter(item => item !== id)
        : [...prev, id]
    );
  };

  const filteredFAQ = faqData.map(category => ({
    ...category,
    questions: category.questions.filter(q => 
      q.question.toLowerCase().includes(searchTerm.toLowerCase()) ||
      q.answer.toLowerCase().includes(searchTerm.toLowerCase())
    )
  })).filter(category => category.questions.length > 0);

  return (
    <div className="p-6 space-y-6 max-w-6xl mx-auto">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <Button variant="outline" onClick={() => window.history.back()} className="mb-4 md:mb-0">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Voltar
          </Button>
          <h1 className="text-2xl font-bold text-gray-900">Central de Suporte</h1>
          <p className="text-gray-600 mt-1">Tire suas dúvidas e solicite ajuda</p>
        </div>
      </div>

      <Tabs defaultValue="perguntas-frequentes" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="perguntas-frequentes">Perguntas Frequentes</TabsTrigger>
          <TabsTrigger value="abrir-chamado">Abrir Chamado</TabsTrigger>
          <TabsTrigger value="meus-chamados">Meus Chamados</TabsTrigger>
          <TabsTrigger value="contato-direto">Contato Direto</TabsTrigger>
        </TabsList>

        <TabsContent value="perguntas-frequentes" className="space-y-6">
          {/* Search */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Search className="h-5 w-5 mr-2" />
                Buscar em Perguntas e Respostas
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-2">
                <Input
                  placeholder="Buscar perguntas, respostas ou tags..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="flex-1"
                />
                <div className="flex space-x-2">
                  {faqData.map((category) => {
                    const Icon = category.icon;
                    return (
                      <Badge key={category.category} className={category.color}>
                        <Icon className="h-3 w-3 mr-1" />
                        {category.category}
                      </Badge>
                    );
                  })}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* FAQ Categories */}
          <div className="space-y-4">
            {filteredFAQ.map((category) => {
              const Icon = category.icon;
              return (
                <Card key={category.category}>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Icon className="h-5 w-5 mr-2" />
                      {category.category}
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-2">
                      {category.questions.map((faq, index) => {
                        const itemId = `${category.category}-${index}`;
                        const isOpen = openItems.includes(itemId);
                        
                        return (
                          <Collapsible key={itemId}>
                            <CollapsibleTrigger 
                              className="flex items-center justify-between w-full p-3 text-left border rounded-lg hover:bg-gray-50 transition-colors"
                              onClick={() => toggleItem(itemId)}
                            >
                              <span className="font-medium text-gray-900">{faq.question}</span>
                              {isOpen ? (
                                <ChevronDown className="h-4 w-4 text-gray-500" />
                              ) : (
                                <ChevronRight className="h-4 w-4 text-gray-500" />
                              )}
                            </CollapsibleTrigger>
                            <CollapsibleContent className="p-3 border-t border-gray-100 bg-gray-50 rounded-b-lg">
                              <p className="text-gray-700">{faq.answer}</p>
                            </CollapsibleContent>
                          </Collapsible>
                        );
                      })}
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="abrir-chamado">
          <Card>
            <CardHeader>
              <CardTitle>Abrir Novo Chamado</CardTitle>
              <CardDescription>Descreva sua dúvida ou problema detalhadamente</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Funcionalidade em desenvolvimento...</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="meus-chamados">
          <Card>
            <CardHeader>
              <CardTitle>Meus Chamados</CardTitle>
              <CardDescription>Acompanhe o status dos seus chamados</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-gray-600">Nenhum chamado encontrado.</p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="contato-direto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="text-center">
                <MessageSquare className="h-8 w-8 mx-auto text-blue-600 mb-2" />
                <CardTitle>Chat Online</CardTitle>
                <CardDescription>Converse conosco em tempo real</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <Button className="w-full">Iniciar Chat</Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <Phone className="h-8 w-8 mx-auto text-green-600 mb-2" />
                <CardTitle>Telefone</CardTitle>
                <CardDescription>Ligue para nosso suporte</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <p className="font-medium mb-2">(11) 9999-9999</p>
                <p className="text-sm text-gray-600">Seg-Sex: 8h às 18h</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader className="text-center">
                <Mail className="h-8 w-8 mx-auto text-purple-600 mb-2" />
                <CardTitle>E-mail</CardTitle>
                <CardDescription>Envie sua dúvida por e-mail</CardDescription>
              </CardHeader>
              <CardContent className="text-center">
                <p className="font-medium mb-2">suporte@canteirocircular.com</p>
                <p className="text-sm text-gray-600">Resposta em até 24h</p>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
