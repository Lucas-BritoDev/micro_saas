
import { useState } from "react";
import { MetricCard } from "@/components/dashboard/MetricCard";
import { QuickActions } from "@/components/dashboard/QuickActions";
import { AlertsNotifications } from "@/components/dashboard/AlertsNotifications";
import { 
  BarChart3, 
  FileText, 
  Leaf, 
  DollarSign,
  Calendar,
  Download 
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/components/ui/use-toast";
import { exportDashboardData } from "@/utils/exportUtils";

export default function Dashboard() {
  const [selectedPeriod, setSelectedPeriod] = useState("atual");
  const { toast } = useToast();

  const handleExport = () => {
    try {
      exportDashboardData([]);
      toast({
        title: "Relatório exportado",
        description: "O relatório do dashboard foi baixado com sucesso.",
      });
    } catch (error) {
      toast({
        title: "Erro",
        description: "Ocorreu um erro ao exportar o relatório.",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="p-6 space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <p className="text-gray-600 mt-1">Visão geral da sua performance ESG</p>
        </div>
        <div className="flex items-center space-x-3 mt-4 md:mt-0">
          <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
            <SelectTrigger className="w-[180px]">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue placeholder="Selecionar período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="atual">Período Atual</SelectItem>
              <SelectItem value="ultimo-mes">Último Mês</SelectItem>
              <SelectItem value="ultimos-3-meses">Últimos 3 Meses</SelectItem>
              <SelectItem value="ultimos-6-meses">Últimos 6 Meses</SelectItem>
              <SelectItem value="ano-atual">Ano Atual</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline" size="sm" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Exportar
          </Button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <MetricCard
          title="Score IMC"
          value="85/100"
          change="+8 pts"
          changeType="positive"
          icon={BarChart3}
          iconColor="text-blue-500"
        />
        <MetricCard
          title="MTR Ativos"
          value="12"
          change="+2"
          changeType="positive"
          icon={FileText}
          iconColor="text-green-500"
        />
        <MetricCard
          title="Score ESG"
          value="78/100"
          change="+5 pts"
          changeType="positive"
          icon={Leaf}
          iconColor="text-purple-500"
        />
        <MetricCard
          title="Receita Mensal"
          value="R$ 450k"
          change="+12%"
          changeType="positive"
          icon={DollarSign}
          iconColor="text-orange-500"
        />
      </div>

      {/* Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <QuickActions />
        <AlertsNotifications />
      </div>
    </div>
  );
}
