
import * as XLSX from 'xlsx';

export const exportToXLS = (data: any[], filename: string, sheetName: string = 'Sheet1') => {
  try {
    const ws = XLSX.utils.json_to_sheet(data);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName);
    XLSX.writeFile(wb, `${filename}.xlsx`);
  } catch (error) {
    console.error('Error exporting to XLS:', error);
    throw new Error('Erro ao exportar arquivo Excel');
  }
};

export const exportDashboardData = (metrics: any[]) => {
  const data = [
    { Métrica: 'Score IMC', Valor: '85/100', Variação: '+8 pts' },
    { Métrica: 'MTR Ativos', Valor: '12', Variação: '+2' },
    { Métrica: 'Score ESG', Valor: '78/100', Variação: '+5 pts' },
    { Métrica: 'Receita Mensal', Valor: 'R$ 450k', Variação: '+12%' },
  ];
  
  exportToXLS(data, 'dashboard-report', 'Dashboard');
};

export const exportIMCResults = (assessment: any) => {
  const data = [
    { Categoria: 'Pontuação Total', Valor: assessment.score || 0 },
    { Categoria: 'Environmental', Valor: assessment.category_scores?.environmental || 0 },
    { Categoria: 'Social', Valor: assessment.category_scores?.social || 0 },
    { Categoria: 'Governance', Valor: assessment.category_scores?.governance || 0 },
  ];
  
  exportToXLS(data, 'imc-assessment-results', 'Avaliação IMC');
};

export const exportMTRData = (mtrs: any[]) => {
  const data = mtrs.map(mtr => ({
    'Número MTR': mtr.mtr_number,
    'Projeto': mtr.project_name,
    'Tipo de Resíduo': mtr.waste_type,
    'Quantidade': mtr.quantity,
    'Unidade': mtr.unit,
    'Status': mtr.status,
    'Data de Emissão': new Date(mtr.issue_date).toLocaleDateString('pt-BR'),
    'Data de Vencimento': new Date(mtr.due_date).toLocaleDateString('pt-BR'),
    'Localização': mtr.location
  }));
  
  exportToXLS(data, 'mtrs-report', 'MTRs');
};

export const exportESGData = (goals: any[], metrics: any[]) => {
  const data = [
    ...goals.map(goal => ({
      Tipo: 'Meta',
      Categoria: goal.category,
      Título: goal.title,
      'Valor Atual': goal.current_value,
      'Valor Meta': goal.target_value,
      'Data Meta': new Date(goal.target_date).toLocaleDateString('pt-BR')
    })),
    ...metrics.map((metric, index) => ({
      Tipo: 'Métrica',
      Categoria: ['Environmental', 'Social', 'Governance'][index % 3],
      Título: `Métrica ${index + 1}`,
      'Valor Atual': metric.value,
      'Valor Meta': '-',
      'Data Meta': '-'
    }))
  ];
  
  exportToXLS(data, 'esg-report', 'ESG');
};

export const exportFinancialData = (transactions: any[]) => {
  const data = transactions.map(transaction => ({
    'Descrição': transaction.description,
    'Projeto': transaction.project,
    'Valor': transaction.amount,
    'Tipo': transaction.type === 'income' ? 'Receita' : 'Despesa',
    'Data': new Date(transaction.date).toLocaleDateString('pt-BR'),
    'Categoria': transaction.category || 'Não categorizado'
  }));
  
  exportToXLS(data, 'financial-transactions', 'Transações');
};
