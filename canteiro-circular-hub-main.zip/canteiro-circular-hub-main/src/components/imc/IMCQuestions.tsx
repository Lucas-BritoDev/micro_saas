
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';

interface Question {
  id: string;
  category: string;
  question: string;
  options: { value: string; label: string; points: number }[];
}

interface IMCQuestionsProps {
  questions: Question[];
  answers: Record<string, string>;
  onAnswerChange: (questionId: string, value: string) => void;
  currentQuestion: number;
}

export const IMCQuestions: React.FC<IMCQuestionsProps> = ({
  questions,
  answers,
  onAnswerChange,
  currentQuestion
}) => {
  const question = questions[currentQuestion];
  const progress = ((currentQuestion + 1) / questions.length) * 100;

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-center mb-2">
          <CardTitle className="text-lg">
            Questão {currentQuestion + 1} de {questions.length}
          </CardTitle>
          <span className="text-sm text-gray-500">
            {question.category}
          </span>
        </div>
        <Progress value={progress} className="mb-4" />
        <CardDescription className="text-base font-medium text-gray-900">
          {question.question}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <RadioGroup
          value={answers[question.id] || ''}
          onValueChange={(value) => onAnswerChange(question.id, value)}
        >
          {question.options.map((option) => (
            <div key={option.value} className="flex items-center space-x-2">
              <RadioGroupItem value={option.value} id={option.value} />
              <Label htmlFor={option.value} className="text-sm">
                {option.label}
              </Label>
            </div>
          ))}
        </RadioGroup>
      </CardContent>
    </Card>
  );
};
