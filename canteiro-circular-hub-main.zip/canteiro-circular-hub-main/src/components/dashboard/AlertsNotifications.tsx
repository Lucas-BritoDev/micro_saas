
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertTriangle, Info } from "lucide-react";

export function AlertsNotifications() {
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-6">
      <div className="flex items-center mb-4">
        <AlertTriangle className="h-5 w-5 text-amber-500 mr-2" />
        <h3 className="text-lg font-semibold text-gray-900">Alertas e Notificações</h3>
      </div>
      
      <div className="space-y-3">
        <Alert className="border-amber-200 bg-amber-50">
          <AlertTriangle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="text-amber-800">
            <strong>MTR vencendo em 3 dias</strong><br />
            MTR-2024-003 - Resíduos de concreto<br />
            <span className="text-sm text-amber-600">17/01/2024</span>
          </AlertDescription>
        </Alert>

        <Alert className="border-blue-200 bg-blue-50">
          <Info className="h-4 w-4 text-blue-600" />
          <AlertDescription className="text-blue-800">
            <strong>Nova meta ESG disponível!</strong><br />
            Configure metas de redução de carbono<br />
            <span className="text-sm text-blue-600">16/01/2024</span>
          </AlertDescription>
        </Alert>
      </div>
    </div>
  );
}
